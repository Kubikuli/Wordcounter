// io.h
// IJC-DU2, příklad 2), 22.4.2024
// Author: Jakub Lůčný, VUT FIT
// Compiled with: gcc 11.4.0
/*
    Header file for read_word() function
*/

#include <stdio.h>

int read_word(char *s, int max, FILE *f);
